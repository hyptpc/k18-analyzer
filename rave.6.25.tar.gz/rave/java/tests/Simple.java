import at.hephy.Rave.*;

public class Simple
{
//  static {
// rave.init();
//  }

  public static void main( String[] args )
  {
   System.out.println( "" );
   System.out.println( "===================================" );
   System.out.println( "         Simple.java" );
   System.out.println( "This is Rave "+ rave.RaveVersion() );
   System.out.println( "===================================" );
   System.out.println( "" );
  }
}
