// -*- C++ -*-
// $Id: ArgumentList.hh,v 1.2 2003/09/06 14:04:13 boudreau Exp $
#ifndef __ARGUMENT_LIST__
#define __ARGUMENT_LIST__
#include "CLHEP/GenericFunctions/Argument.hh"
namespace Genfun {
  typedef std::vector<Argument> ArgumentList;
} // namespace Genfun
#endif 
